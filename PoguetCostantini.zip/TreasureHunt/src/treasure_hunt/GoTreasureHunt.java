package treasure_hunt;

public class GoTreasureHunt {
	
	@SuppressWarnings("unused")
	public static void main(String[] args) throws InterruptedException {
		GameFrame gf = new GameFrame();
	}
	
}
