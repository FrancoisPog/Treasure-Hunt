package treasure_hunt;

import java.util.Scanner;

public class GoTreasureHuntConsole {
	
	public static void main(String[] args) throws InterruptedException {
		boolean replay = false;
		Scanner sc = new Scanner(System.in);
		do {
			Game game = Game.welcome();
			game.play();
			game.result();
			System.out.println("Do you want to replay ? (y/n)");
			replay = sc.next().equalsIgnoreCase("y");
		}while(replay);
		
		sc.close();
	}
}
 